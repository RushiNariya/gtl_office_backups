import "./App.css";
import TodoList from "./components/TodoList/TodoList";

function App() {

  return (
    <div className="appContainer">
      <TodoList />
    </div>
  );
  
}

export default App;
