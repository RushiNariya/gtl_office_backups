import React from "react";
import { connect } from "react-redux";
import DeleteIcon from "@material-ui/icons/Delete";
import { Box, Checkbox, Switch } from "@material-ui/core";

import "./style.css";
import {
  deleteTodoSuccess,
  getTodosRequest,
  getTodosSuccess,
  //   getTodosFailure,
  postTodoSuccess,
  todoStatusChange,
} from "../../redux/ActionCreators/TodoActionCreators";

function Todo(props) {
  const { id, name, isActive } = props.todo;
  const { todos, postTodoSuccess, deleteTodoSuccess, todoStatusChange } = props;

  const deleteTodoSuccessById = (id) => {
    getTodosRequest();
    deleteTodoSuccess(id);
  };

  const todoCompleted = (id) => {
    // if (isActive) {
    var element = document.getElementById(id);
    element.classList.toggle("todoCompleted");
    // }

    todoStatusChange(id);
  };

  return (
    <Box display="flex" p={2} className="container" bgcolor="background.paper">
      <div>
        <Checkbox
          id={`todo${id}`}
          checked={isActive}
          onClick={() => todoCompleted(id)}
          color="primary"
          inputProps={{ "aria-label": "secondary checkbox" }}
        />
        <label htmlFor={`todo${id}`} className="" id={id}>
          {name}
        </label>
      </div>

      <DeleteIcon onClick={() => deleteTodoSuccessById(id)} />
    </Box>
  );
}

const mapStateToProps = (state) => {
  return {
    todos: state.todoReducer.todos,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getTodosRequest: () => dispatch(getTodosRequest()),
    getTodosSuccess: (todo) => dispatch(getTodosSuccess(todo)),
    postTodoSuccess: (data) => dispatch(postTodoSuccess(data)),
    deleteTodoSuccess: (id) => dispatch(deleteTodoSuccess(id)),
    todoStatusChange: (id) => dispatch(todoStatusChange(id)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Todo);
