import React from "react";
import { connect } from "react-redux";
import DeleteIcon from "@material-ui/icons/Delete";
import "./style.css";
import {
  deleteTodoSuccess,
  getTodosRequest,
  getTodosSuccess,
  //   getTodosFailure,
  postTodoSuccess,
  todoStatusChange,
} from "../../redux/ActionCreators/TodoActionCreators";
import { Box, Checkbox, Switch } from "@material-ui/core";

function Todo(props) {
  const { id, name, isActive } = props.todo;
  const { todos, postTodoSuccess, deleteTodoSuccess,todoStatusChange } = props;

  const deleteTodoSuccessById = (id) => {
    // getTodosRequest();
    // console.log("rushi");
    // const newTodos = todos.filter((todo) => {
    //   return todo.id != id;
    // });
    // console.log("object", newTodos);
    deleteTodoSuccess(id);
  };

  const todoCompleted = (id) => {
    todoStatusChange(id);
  }

  return (
    // <div className="container">
    <Box display="flex" p={2} className="container" bgcolor="background.paper">
      <div>
      <Checkbox
        checked = {isActive}
        onClick = {() => todoCompleted(id)}
        color="primary"
        inputProps={{ 'aria-label': 'secondary checkbox' }}
      />
      {name}
      </div>
 
      <DeleteIcon onClick={() => deleteTodoSuccessById(id)} className="" />
    </Box>
    // </div>
  );
}

const mapStateToProps = (state) => {
  return {
    todos: state.todoReducer.todos,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getTodosRequest: () => dispatch(getTodosRequest()),
    getTodosSuccess: (todo) => dispatch(getTodosSuccess(todo)),
    postTodoSuccess: (data) => dispatch(postTodoSuccess(data)),
    deleteTodoSuccess: (id) => dispatch(deleteTodoSuccess(id)),
    todoStatusChange: (id) => dispatch(todoStatusChange(id)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Todo);
