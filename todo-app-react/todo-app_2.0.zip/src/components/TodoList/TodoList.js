import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";

import Todo from "./Todo";
import {
  getTodosRequest,
  getTodosSuccess,
  getTodosFailure,
  postTodoSuccess,
  setFilter,
} from "../../redux/ActionCreators/TodoActionCreators";
import AddTodo from "../AddTodo/AddTodo";
import { Container } from "@material-ui/core";

const list = [
  { id: 0, name: "todo1", isActive: true },
  { id: 1, name: "todo2", isActive: true },
  { id: 2, name: "todo3", isActive: true },
  { id: 3, name: "todo4", isActive: true },
];

// function DisabledTabs() {

//   return (

//   );
// }

function TodoList({
  filter,
  todos,
  todoNumber,
  getTodosRequest,
  getTodosSuccess,
  postTodoSuccess,
  setFilter,
}) {
  useEffect(async () => {
    getTodosRequest();
    await getData(list);
  }, []);

  const [value, setValue] = React.useState(0);

  const completedTodos = todos.filter(function (todo) {
    if (todo.isActive == false) {
      return todo;
    }
  });

  const ActiveTodos = todos.filter(function (todo) {
    if (todo.isActive == true) {
      return todo;
    }
  });

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const getData = (list) =>
    new Promise((resolve, reject) => {
      getTodosSuccess(list);
      resolve(true);
    });

  // const getFilterData = (filter) => {

  //   if(filter == "All"){
  //   }
  //   else if(filter == "Completed"){
  //     todos = todos.filter(function(todo){
  //       if(todo.isActive == false){
  //         return todo;
  //       }
  //     })
  //   }else{
  //     todos = todos.filter(function(todo){
  //       if(todo.isActive == true){
  //         return todo;
  //       }
  //     });
  //   }
  //   console.log(todos)
  // }

  const filterTodo = (newFilter) => {
    setFilter(newFilter);
    // getFilterData(filter);
    // console.log("call filter mwthod")
  };

  return (
    // <div className="">
    <React.Fragment>
      <Container maxwidth="lg" className="todoListContainer">
        {filter == "All" ? <AddTodo /> : null}
        {/* {todos.map((todo, index) => {
        return <Todo key={index} todo={todo} />;
      })} */}
        {filter == "All"
          ? todos.map((todo, index) => {
              return <Todo key={index} todo={todo} />;
            })
          : filter == "Completed" ? completedTodos.map((todo, index) => {
            return <Todo key={index} todo={todo} />;
          }) : ActiveTodos.map((todo, index) => {
            return <Todo key={index} todo={todo} />;
          })}
      </Container>

      <Paper square>
        <Tabs
          value={value}
          indicatorColor="primary"
          textColor="primary"
          onChange={handleChange}
          aria-label="disabled tabs example"
        >
          <Tab label="All" onClick={() => filterTodo("All")} />
          <Tab label="Active" onClick={() => filterTodo("Active")} />
          <Tab label="Completed" onClick={() => filterTodo("Completed")} />
        </Tabs>
      </Paper>
    </React.Fragment>

    // </div>
  );
}

const mapStateToProps = (state) => {
  return {
    todos: state.todoReducer.todos,
    todoNumber: state.todoReducer.todoNumber,
    filter: state.todoReducer.filter,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getTodosRequest: () => dispatch(getTodosRequest()),
    getTodosSuccess: (todo) => dispatch(getTodosSuccess(todo)),
    postTodoSuccess: (data) => dispatch(postTodoSuccess(data)),
    setFilter: (filter) => dispatch(setFilter(filter)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
