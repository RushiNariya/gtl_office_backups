import React from "react";
import { connect } from "react-redux";
import "./style.css";
import {
  deleteTodo,
  getTodosRequest,
  getTodosSuccess,
  //   getTodosFailure,
  postTodo,
} from "../../redux/ActionCreators/TodoActionCreators";

function Todo(props) {
  const { id, name } = props.todo;
  //   console.log(name);
  const { todos, postTodo, deleteTodo } = props;

  const deleteTodoById = (id) => {
    // getTodosRequest();
    // console.log("rushi");
    // const newTodos = todos.filter((todo) => {
    //   return todo.id != id;
    // });
    // console.log("object", newTodos);
    deleteTodo(id);
  };

  return (
    <div className="container">
      <h5>{name}</h5>
      <button onClick={() => deleteTodoById(id)}>delete</button>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    todos: state.todoReducer.todos,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getTodosRequest: () => dispatch(getTodosRequest()),
    getTodosSuccess: (todo) => dispatch(getTodosSuccess(todo)),
    postTodo: (data) => dispatch(postTodo(data)),
    deleteTodo: (id) => dispatch(deleteTodo(id)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Todo);
