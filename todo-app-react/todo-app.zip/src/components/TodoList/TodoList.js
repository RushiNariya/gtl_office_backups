import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import Todo from "./Todo";
import {
  getTodosRequest,
  getTodosSuccess,
  getTodosFailure,
  postTodo,
} from "../../redux/ActionCreators/TodoActionCreators";

const list = [
  { id: 1, name: "todo1" },
  { id: 2, name: "todo2" },
  { id: 3, name: "todo3" },
  { id: 4, name: "todo4" },
];

function TodoList({ todos, getTodosRequest, getTodosSuccess, postTodo }) {
  useEffect(async () => {
    getTodosRequest();
    await getData(list);
  }, []);

  const getData = (list) =>
    new Promise((resolve, reject) => {
      getTodosSuccess(list);
      resolve(true);
    });

  const [newTodo, setNewTodo] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const newOne = {
      id: 5,
      name: newTodo,
    };
    postTodo(newOne);
  };

  console.log(todos);

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="todo"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
        />
        <button type="submit">add new todo</button>
      </form>
      {todos.map((todo, index) => {
        return <Todo key={index} todo={todo} />;
      })}
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    todos: state.todoReducer.todos,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getTodosRequest: () => dispatch(getTodosRequest()),
    getTodosSuccess: (todo) => dispatch(getTodosSuccess(todo)),
    postTodo: (data) => dispatch(postTodo(data)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
