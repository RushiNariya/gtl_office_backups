import {
  GET_TODOS_REQUEST,
  GET_TODOS_SUCCESS,
  GET_TODOS_FAILURE,
  POST_TODO,
  DELETE_TODO,
} from "../ActionTypes/TodoActionTypes";

export const getTodosRequest = () => {
  return {
    type: GET_TODOS_REQUEST,
  };
};

export const getTodosSuccess = (todos) => {
  // console.log(todos);
  return {
    type: GET_TODOS_SUCCESS,
    payload: todos,
  };
};

export const getTodosFailure = (err) => {
  return {
    type: getTodosFailure,
    error: err,
  };
};

export const postTodo = (todo) => {
  return {
    type: POST_TODO,
    newTodo: todo,
  };
};

export const deleteTodo = (id) => {
  return {
    type: DELETE_TODO,
    id: id,
  };
};
