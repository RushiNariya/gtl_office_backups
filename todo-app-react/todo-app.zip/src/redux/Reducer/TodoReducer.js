import {
  GET_TODOS_REQUEST,
  GET_TODOS_SUCCESS,
  GET_TODOS_FAILURE,
  POST_TODO,
  DELETE_TODO,
} from "../ActionTypes/TodoActionTypes";

const initialState = {
  isLoading: false,
  todos: [],
  error: null,
  // isCompleted: false,
  // isActive: true,
};

const todoReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_TODOS_REQUEST:
      return {
        ...state,
        isLoading: true,
      };
    case GET_TODOS_SUCCESS:
      return {
        ...state,
        isLoading: false,
        todos: action.payload,
      };
    case GET_TODOS_FAILURE:
      return {
        ...state,
        isLoading: false,
        todos: [],
        error: action.error,
      };

    case POST_TODO:
      return {
        ...state,
        todos: [...state.todos, action.newTodo],
      };

    case DELETE_TODO:
      return {
        ...state,
        todos: state.todos.filter(function (todo) {
          return todo.id != action.id;
        }),
      };
    default:
      return state;
  }
};

export default todoReducer;
