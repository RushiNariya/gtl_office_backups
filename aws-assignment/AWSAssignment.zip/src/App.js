import logo from './logo.svg';
import './App.css';
import Dashboard from './Components/Dashboard';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { Redirect } from 'react-router'


function App() {
  return (
    (
      <BrowserRouter>
         <div className="App">
        <Switch>

        <Route path="*" component={Dashboard} />

        </Switch>
        </div>
    </BrowserRouter>
    )
  );
}

export default App;
