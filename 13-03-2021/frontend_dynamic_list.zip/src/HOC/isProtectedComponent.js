import React from 'react'
// import { connect } from "react-redux";
import Dashboard from "../component/Dashboard/Dashboard";
import Login from "../component/Login/Login";

function isProtectedComponent(Component) {
  console.log("----------------------------------inside HOC")
  return class applyProtected extends React.Component {
    constructor(props) {
      super(props);
      this.selectValidateSession = function() {
        console.log("----------------------------------inside Method")

        const history = props.history;
        const token = sessionStorage.getItem("token");
        console.log(token)
        if(Boolean(!token) || token === 'undefined' || token === 'null'){
          sessionStorage.removeItem('token');
          history.push('/login');
          return false;
        }
        return true;
      }
    }

    // componentWillMount() {
    //   this.selectValidateSession(this.props);
    // }

    // componentWillReceiveProps(props) {
    //     this.selectValidateSession(props);
    // }
    

    render() {

      if(this.selectValidateSession(this.props) && Component) {
        console.log("---------------------dashboard")
        return (
          <Component {...this.props} />
        )
      }
      console.log("---------------------Login")
      return (
        <Login {...this.props} />
      )
    }
  }
}

export default isProtectedComponent ;