const BASE_URL = "https://horsella-backend.herokuapp.com/api";
// const BASE_URL = "http://localhost:5000/api";

module.exports = {
  BASE_URL,
};
